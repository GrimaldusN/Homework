import java.util.Scanner;

 public class Exrc2 {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        Scanner scn = new Scanner(System.in);
        String userStr = "";
        int sum = 0;

        while (userStr != "quite"){

                System.out.println("press num");
                int num = scr.nextInt();

                if (num % 2 == 1){
                    for (int i = 0;i<1;){
                        sum= sum+num;
                        i++;
                        System.out.println("sum = " + sum);
                    }
                }
                else {
                    System.out.println("sum num%2 = " + sum);
                }
                System.out.println("quite -> exit");
                userStr = scn.nextLine();
        }

    }
}
