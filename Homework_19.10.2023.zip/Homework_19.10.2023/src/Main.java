import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Random rnd = new Random(4);
        int rand = rnd.nextInt();
        int a = 0;
        int sum = 0;
        int i = 0;

        do {
            switch (rand) {
                case 1 -> a = 50;
                case 2 -> a = 100;
                case 3 -> a = 200;
                default -> a = 500;
            }
            i = sum + a;
        } while (i < 10_000);
        System.out.println("Выпьем за моё здоровье!!");


    }
}