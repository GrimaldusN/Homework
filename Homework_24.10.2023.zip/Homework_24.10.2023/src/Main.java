public class Main {
    public static void main(String[] args) {
        int num1 = 4;
        int num2 = 4;
        int num3 = 4;
        int num4 = 6;
        int a = Sor(num1,num2);
        int b = Sor(a,num3);
        int c = Sor(b,num4);
    }

    private static int Sor(int num1, int num2){
        int a = num1*num2;
        System.out.println(a);
        return a;
    }
}


