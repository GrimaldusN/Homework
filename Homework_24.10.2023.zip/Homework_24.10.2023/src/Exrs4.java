import java.util.Arrays;

public class Exrs4 {
    public static void main(String[] args) {
        int[][] arrays = { {},{},{},{},{} };
        System.out.println(Arrays.toString(arrays));
    }
}
