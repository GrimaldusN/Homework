import java.util.Arrays;
import java.util.Scanner;

public class Exrc2 {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        int n = scr.nextInt();
        int[] array = new int[n];
        for (int i=0; i!=n ; i++) {
            array[i] = i + 1;
        }
        System.out.println(Arrays.toString(array));

        for (int x=0; x!=n ; x++ ) {
            array[0] = array[0] * array[x];
        }
        System.out.println("n! = " + array[0]);

    }
}
