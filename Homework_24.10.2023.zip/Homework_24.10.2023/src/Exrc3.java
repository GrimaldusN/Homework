import java.util.Arrays;
import java.util.Random;

public class Exrc3 {
    public static void main(String[] args) {
        Random rand = new Random();
        int[] array = new int[8];
        for (int i = 0; i!=8; i++){
            int n = rand.nextInt(1,50);
            array[i] = n;
        }
        System.out.println(Arrays.toString(array));
        for (int i = 0; i!=8; i++){
            if (array[i]%2==1){
                array[i]= 0;
            }
        }
        System.out.println(Arrays.toString(array));
        Arrays.sort(array);
        System.out.println(Arrays.toString(array));
    }
}

