import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Введите имя,возраст(полных лет) и вес, строго в даном порядке");
        Scanner scn = new Scanner(System.in);
        String g = scn.next();
        Scanner old = new Scanner(System.in);
        int years = old.nextInt();
        Scanner weight = new Scanner(System.in);
        int kg = weight.nextInt();
        System.out.printf("Уважаемый," + g + " ! В свои " + years + " лет Вы для нас дороги, как " + kg + " килограмм золота.. ");
    }
}