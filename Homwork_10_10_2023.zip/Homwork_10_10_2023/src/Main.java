import java.util.Random;
import java.util.UUID;

public class Main {
    public static void main(String[] args) {
        Random rnd = new Random();
        int one = rnd.nextInt();
        System.out.println("int " + one);
        byte[] two = new byte[20];
        new Random().nextBytes(two);
        System.out.println("byte " + two);
        short three = (short) rnd.nextInt();
        System.out.println("short " + three);
        char four = (char) rnd.nextInt();
        System.out.println("char " + four);
        long five = rnd.nextLong();
        System.out.println("long " + five);
        float six = rnd.nextFloat();
        System.out.println("float " + six);
        double seven = rnd.nextDouble();
        System.out.println("double " + seven);
        String str = UUID.randomUUID().toString();
        System.out.print(str);
    }
}