import java.util.Arrays;

public class Exrc2 {
    public static void main(String[] args) {
        char[][] a = new char[3][3];
        System.out.println(Arrays.deepToString(a));
        char letter = 'А';
        for (int i = 0; i <=a.length; i++) {
            for (int j = 0; j <=a[i].length; j++) {
                a[i][j] = letter++;
                if (letter++ == 'Е'){
                    a[i][j] = 'Ё';
                }
                if (letter > 'Я'){
                    break;
                }

            }

        }
        System.out.println(Arrays.deepToString(a));
    }
}