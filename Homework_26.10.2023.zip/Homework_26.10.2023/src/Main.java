import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {
            LocalDate[] dates = {
                    LocalDate.of(1989, 8, 14),
                    LocalDate.of(2000, 8, 16),
                    LocalDate.of(1965, 8, 15),
                    LocalDate.of(1999, 8, 13),
                    LocalDate.of(1989, 8, 18),
                    LocalDate.of(1989, 8, 14)
            };
        //System.out.println(binarySearch(dates,2000,0, dates.length-1).toString());

        }

    private static int binarySearch(int[] array, int findMe, int low, int high) {
        if (low == high) {
            return array[low] == findMe ? low : -1;
        }
        int mid = low + (high - low) / 2;

        if (findMe == array[mid]) return mid;

        if (findMe < array[mid]) {
            return binarySearch(array, findMe, low, mid);
        } else {
            return binarySearch(array, findMe, mid + 1, high);

        }
    }
}
