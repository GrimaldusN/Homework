public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        System.out.printf("mne %d let. i love %s color", 17, "pink");
        System.out.println(" ");
        System.out.printf("mne %d let. i love %s color", 17, "pink");
        System.out.println(" ");
        System.out.println("Hello,");
        System.out.println("my");
        System.out.println("name");
        System.out.println("is");
        System.out.println("Oleksandr");
        System.out.print("Hello, my name is Oleksandr");
    }
}