public class Main {
    public static void main(String[] args) {
        double a = Math.random();
        double b = Math.random();
        double abs = Math.abs(a-b);
        double min = Math.min(a,b);
        double max = Math.max(a,b);
        double g = Math.pow(a,b*10);
        System.out.println(abs);
        System.out.println(min);
        System.out.println(max);
        System.out.println(g);

    }
}