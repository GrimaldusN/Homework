public class Main {
    public static void main(String[] args) {
        char g = 'G';
        System.out.println(g);
        int one = 89;
        System.out.println(one);
        byte two = 4;
        System.out.println(two);
        short three = 56;
        System.out.println(three);
        float four = 4.7333436F;
        System.out.println(four);
        double five = 4.355453532;
        System.out.println(five);
        long six = 12121;
        System.out.println(six);
        int x = 345;
        int y = 10;
        int z = x/(y*10);
        int t = x/y%y;
        int r = x%y;
        System.out.println("число 345 --> " + z + ", " + t + ", " + r);

    }
}