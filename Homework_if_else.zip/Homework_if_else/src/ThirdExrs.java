import java.util.Scanner;

public class ThirdExrs {
    public static void main(String[] args) {
        System.out.println("enter the year  ");
        Scanner scr = new Scanner(System.in);
        int year = scr.nextInt();
        if ( year < 1935) {
            System.out.println("Presly didn't born");
        }
        if ( year == 1935) {
            System.out.println("Presly alive!");
        }
        else  {
            System.out.println("Presly forever in our heart's");
        }
    }
}
