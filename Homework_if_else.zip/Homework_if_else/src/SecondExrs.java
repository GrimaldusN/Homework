import java.util.Random;
import java.util.Scanner;

public class SecondExrs {
    public static void main(String[] args) {
        Random rand = new Random();
        int one = rand.nextInt(1,9);
        int two = rand.nextInt(1,9);
        System.out.println("Каков результат умножения " + one + "и" + two);
        Scanner scr = new Scanner(System.in);
        int in = scr.nextInt();
        if (in == one * two) {
            System.out.println("верно");
        }
        else {
            System.out.println("не верно");
        }

    }
}


