import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner one = new Scanner(System.in);
        double first = one.nextDouble();
        Scanner two = new Scanner(System.in);
        double second = two.nextDouble();
        if (first-10 > second-10) {
            System.out.println(second);
        }
        else {
            System.out.println(first);
        }
       }
    }
