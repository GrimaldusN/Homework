import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Введите два целых числа");
        Scanner scn = new Scanner(System.in);
        int one = scn.nextInt();
        Scanner scr = new Scanner(System.in);
        int two = scr.nextInt();
        int summ = one + two ;
        int minus = one - two ;
        int umnosh = one * two ;
        int deli = one / two ;
        System.out.println(summ);
        System.out.println(minus);
        System.out.println(umnosh);
        System.out.println(deli);
    }
}