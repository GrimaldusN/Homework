import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        StringBuilder one = new StringBuilder(scr.next());
        Scanner sc = new Scanner(System.in);
        StringBuilder two = new StringBuilder(sc.next() + " ");


        if (one.length() % 2 == 0 || two.length() % 2 == 0) {
            int second = two.length() / 2;
            int firs = one.length() / 2;
            System.out.println(one.delete(0, firs).append(two.delete(second, two.lastIndexOf(" "))));
        }
    }

}
