/*public class Exrs3 {

    public static void main(String[] args) {
        StringBuilder str = new StringBuilder("AAAABBBBBCCCCCDDDDDDDDEEEEEEGGGGGG");
        char i = str.toCharArray;
    }

    private static void Sort(StringBuilder array) {
        for (StringBuilder : array ;) {

        }
    }
}

*/