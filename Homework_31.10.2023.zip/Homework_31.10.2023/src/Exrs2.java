public class Exrs2 {

    public static void main(String[] args) {
    String a = new String("I study Basic Java!");
        System.out.println(Last(a));
    }

    private static String[] Last(String original){
        String[] originalArray = original.split(" ");
        System.out.println(originalArray[originalArray.length-1]);
        System.out.println(original.length()-1);
        System.out.println(original.contains("Java"));
        System.out.println(original.replace("a","o"));
        System.out.println(original.toLowerCase());
        System.out.println(original.toUpperCase());
        System.out.println(original.substring(14, 18));
        return originalArray;
    }

}

